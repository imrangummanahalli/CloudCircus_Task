<?php

phpinfo();

?><?php /**PATH D:\Users\Imran\Documents\Laravel\blog\resources\views/phpinfo.blade.php ENDPATH**/ ?>