<?php $id=1?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/main.css')); ?>">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
            <div style="width: 2px;height: 1px;margin-left: 88%;"><a href="<?php echo e(url('logout')); ?>" class="logout">LOGOUT</a></div>
				<div class="userlist">
				<div style="margin-top:-95px;width:max-content;padding-left:21%;">
					<img src="<?php echo e(url('img/cloudcircus.png')); ?>" alt="cloudcircus_image" width="200px" height="200px">
				</div>
            <h1 style="padding-left:13%;padding-top:5px">List Of Registred Users</h1>
            <table id="customers">
        <tr>
            <th>Sr</th>
            <th>Name</th>
            <th>Email</th>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $id;$id++;?></td>
            <td><?php echo e($user['name']); ?></td>
            <td><?php echo e($user['email']); ?></td>
        </tr>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <!-----<div class="container-login100-form-btn" >
				  	<a  class="login100-form-btn" href="<?php echo e(url('logout')); ?>">Logout</a>
				  </div>----->
               
        </div>
			</div>
		</div>
	</div>
    
</body>
</html><?php /**PATH D:\Users\Imran\Documents\Laravel\blog\resources\views/welcome.blade.php ENDPATH**/ ?>