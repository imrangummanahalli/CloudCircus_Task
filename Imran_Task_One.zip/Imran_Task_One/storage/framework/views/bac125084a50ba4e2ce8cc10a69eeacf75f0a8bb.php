<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/main.css')); ?>">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form"  method="POST" action="<?php echo e(url('post-login')); ?>">
				<?php echo e(csrf_field()); ?>

				<div style="padding-left:-10px;width:80%">
				<div style="margin-top:-95px;width:max-content;padding-left:11%;">
					<img src="<?php echo e(url('img/cloudcircus.png')); ?>" alt="cloudcircus_image" width="200px" height="200px">
				</div>
                <div class="" style="padding-top:20px">
					<span class="txt1" >
					<strong>Username</strong>	
					</span>
					<?php if($errors->has('email')): ?>
                  		<span class="error"><?php echo e($errors->first('email')); ?></span>
                  	<?php endif; ?>  
                </div>
					<div class="wrap-input100 ">
						<input class="input100" type="text" name="email" required="Username is required" placeholder="ex:cloudcircus@gmail.com" >
						<span class="focus-input100"></span>
					</div>	
					
					<div style="padding-top:15px">
				<div class="" style="padding-top:10px">
					<span class="txt1">
						<strong>Password</strong>
					</span>
				</div>
					<div class="wrap-input100 validate-input m-b-12">		
						<input class="input100" type="password" name="password" required="Password is required" placeholder="********">
						<span class="focus-input100"></span>
						<?php if($errors->has('password')): ?>
                  			<span class="error"><?php echo e($errors->first('password')); ?></span>
                 	 	<?php endif; ?> 
					</div>
				</div>
					<div class="container-login100-form-btn" >
						<button class="login100-form-btn" type="submit">
							Login
						</button>
				</div>
				<div style="padding-top:10px;padding-left:65px">If you dont have an account?
                  <a class="small" href="<?php echo e(url('registration')); ?>">Sign Up</a>
			</form>
					</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH D:\Users\Imran\Documents\Laravel\blog\resources\views/login.blade.php ENDPATH**/ ?>