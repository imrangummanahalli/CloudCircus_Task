<?php $id=1?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<link rel="stylesheet" type="text/css" href="{{url('css/main.css')}}">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
            <div style="width: 2px;height: 1px;margin-left: 88%;"><a href="{{url('logout')}}" class="logout">LOGOUT</a></div>
				<div class="userlist">
				<div style="margin-top:-95px;width:max-content;padding-left:21%;">
					<img src="{{url('img/cloudcircus.png')}}" alt="cloudcircus_image" width="200px" height="200px">
				</div>
            <h1 style="padding-left:13%;padding-top:5px">List Of Registred Users</h1>
            <table id="customers">
        <tr>
            <th>Sr</th>
            <th>Name</th>
            <th>Email</th>
        </tr>
        @foreach($users as $user)
        <tr>
            <td><?php echo $id;$id++;?></td>
            <td>{{$user['name']}}</td>
            <td>{{$user['email']}}</td>
        </tr>    
        @endforeach
    </table>
    <!-----<div class="container-login100-form-btn" >
				  	<a  class="login100-form-btn" href="{{url('logout')}}">Logout</a>
				  </div>----->
               
        </div>
			</div>
		</div>
	</div>
    
</body>
</html>