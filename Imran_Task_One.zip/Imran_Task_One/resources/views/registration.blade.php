<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<link rel="stylesheet" type="text/css" href="{{url('css/main.css')}}">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form"  method="POST" action="{{url('post-registration')}}">
				{{ csrf_field() }}
				<div style="padding-left:-10px;width:80%">
				<div style="margin-top:-95px;width:max-content;padding-left:11%;">
					<img src="{{url('img/cloudcircus.png')}}" alt="cloudcircus_image" width="200px" height="200px">
				</div>
                <div class="" style="padding-top:20px">
					<span class="txt1" >
					<strong>Name</strong>	
					</span>
					@if ($errors->has('name'))
                     <span class="error">{{ $errors->first('name') }}</span>
                    @endif       
                </div>
					<div class="wrap-input100">
						<input class="input100" type="text" name="name" required="Name is required" placeholder="ex:Akira Tanaka" >
						<span class="focus-input100"></span>
					</div>	
                    <div class="" style="padding-top:20px">
					<span class="txt1" >
					<strong>Email</strong>	
					</span>
					@if ($errors->has('email'))
                  		<span class="error">{{ $errors->first('email') }}</span>
                  	@endif  
                </div>
					<div class="wrap-input100 ">
						<input class="input100" type="text" name="email" required="Username is required" placeholder="ex:cloudcircus@gmail.com" >
						<span class="focus-input100"></span>
					</div>	
					<div style="padding-top:15px">
				<div class="" style="padding-top:10px">
					<span class="txt1">
						<strong>Password</strong>
					</span>
				</div>
					<div class="wrap-input100 validate-input m-b-12">		
						<input class="input100" type="password" name="password" required="Password is required" placeholder="********">
						<span class="focus-input100"></span>
						@if ($errors->has('password'))
                  			<span class="error">{{ $errors->first('password') }}</span>
                 	 	@endif 
					</div>
				</div>
					<div class="container-login100-form-btn" >
						<button class="login100-form-btn" type="submit">
							Register
						</button>
					</div>
					<div style="padding-top:10px;padding-left:65px">If you have an account?
                  <a class="small" href="{{url('login')}}">Sign In</a>
			
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>