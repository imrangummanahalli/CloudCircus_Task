<?php $id=1?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<link rel="stylesheet" type="text/css" href="{{url('css/main.css')}}">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="userlist">
				<div style="margin-top:-95px;width:max-content;padding-left:21%;">
					<img src="{{url('img/cloudcircus.png')}}" alt="cloudcircus_image" width="200px" height="200px">
				</div>
               <br>
               <span class="p404">4<span style="color:red">0</span>4</span>
               <h1 class="notfound">Page <span style="color:red">Not</span> Found</h1>  
               <a href="{{url('login')}}" class="p404login">Login</a>
        </div>
			</div>
	</div>
	</div>
    @include('sweetalert::alert')
</body>
</html>